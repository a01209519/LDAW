@extends("layout")
@section("page_title", "Equipo LDAW")

@section("main_content")
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-3">
			<h1> Jorge </h1>
		</div>
		<div class="col-md-3">
			<h1> Victor </h1>
		</div>
		<div class="col-md-3">
			<h1> Lalo </h1>
		</div>
		<div class="col-md-3">
			<h1> Randy </h1>
		</div>
	</div>

</div>
@endsection
