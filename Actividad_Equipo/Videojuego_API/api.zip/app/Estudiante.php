<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estudiante extends Model
{
    // Nombre de la tabla
    protected $table = 'students';

    //protected $fillable = ['nombreCompleto1', 'fechaCumpleaños1','RFC1','correo1','telefono1','celular1']; 

    

}
